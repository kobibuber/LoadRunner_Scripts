Action()
{

	web_url("Index.htm", 
		"URL=http://127.0.0.1:1080/WebTours/Index.htm", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_url("seed", 
		"URL=https://clientservices.googleapis.com/chrome-variations/seed?osname=win&channel=stable&milestone=115", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://content-autofill.googleapis.com/v1/pages/ChVDaHJvbWUvMTE1LjAuNTc5MC4xNzESFwk32UHgj34xiRIFDeeNQA4SBQ3OQUx6?alt=proto", "Referer=", ENDITEM, 
		LAST);

	lr_think_time(12);

	web_submit_data("login.pl", 
		"Action=http://127.0.0.1:1080/cgi-bin/login.pl", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=http://127.0.0.1:1080/cgi-bin/nav.pl?in=home", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=userSession", "Value=137050.418469016HAtQfDApQtccQHpVift", ENDITEM, 
		"Name=username", "Value=jojo", ENDITEM, 
		"Name=password", "Value=bean", ENDITEM, 
		"Name=login.x", "Value=68", ENDITEM, 
		"Name=login.y", "Value=11", ENDITEM, 
		"Name=JSFormSubmit", "Value=off", ENDITEM, 
		LAST);

	web_image("Search Flights Button", 
		"Alt=Search Flights Button", 
		"Snapshot=t4.inf", 
		EXTRARES, 
		"Url=https://content-autofill.googleapis.com/v1/pages/ChVDaHJvbWUvMTE1LjAuNTc5MC4xNzESLAnrCB0dNWv2fxIFDVRiKa0SBQ17ncSlEgUNHzs5hRIFDdqFmWESBQ2pjkq9?alt=proto", "Referer=", ENDITEM, 
		LAST);

	lr_think_time(36);

	web_custom_request("json", 
		"URL=https://update.googleapis.com/service/update2/json?cup2key=13:2ZPVS6sg8lB_Un1hhDo5q0IhymumsJ2_iEVjgDUMoxM&cup2hreq=cdc4221a7a06405f4108c079b7771aed64adb2e3e47719e535af8b408a86994c", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx3,puff\",\"app\":[{\"_internal_experimental_sets\":\"false\",\"appid\":\"gonpemdgkjcecdgbnaabipppbmgfggbe\",\"brand\":\"GCEA\",\"cohort\":\"1:z1x:\",\"cohortname\":\"Auto General release\",\"enabled\":true,\"installdate\":5971,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.5a506939f22e0e53bd8b919b551401480815141ab3143004ac047b045713615b\"}]},\"ping\":{\"ping_freshness\":\""
		"{85740222-25d3-488e-8134-994cf5049348}\",\"rd\":6066},\"updatecheck\":{},\"version\":\"2023.8.9.0\"},{\"appid\":\"ihnlcenocehgdaegdmhbidjhnhdchfmm\",\"brand\":\"GCEA\",\"cohort\":\"1::\",\"enabled\":true,\"installdate\":5971,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{d0a10ac9-21f3-493a-aef2-97186c38a7b8}\",\"rd\":6066},\"updatecheck\":{},\"version\":\"0.0.0.0\"},{\"appid\":\"hnimpnehoodheedghdeeijklkeaacbdc\",\"brand\":\"GCEA\",\"cohort\":\"1::\",\"enabled\":true,\"installdate\":5971,\""
		"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.6f6bc93dcd62dc251850d2ff458fda96083ceb7fbe8eeb11248b8485ef2aea23\"}]},\"ping\":{\"ping_freshness\":\"{456ec24b-d824-41e4-a6af-b30851f6ca0e}\",\"rd\":6066},\"updatecheck\":{},\"version\":\"0.57.44.2492\"},{\"appid\":\"oimompecagnajdejgnnjijobebaeigek\",\"brand\":\"GCEA\",\"cohort\":\"1:1unx:\",\"cohortname\":\"Chrome 115+\",\"enabled\":true,\"installdate\":5971,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\""
		"{a6d5e9d6-7f34-45ca-8f03-2dd28c950672}\",\"rd\":6066},\"updatecheck\":{},\"version\":\"4.10.2662.3\"},{\"appid\":\"gcmjkmgdlgnkkcocmoeiminaijmmjnii\",\"brand\":\"GCEA\",\"cohort\":\"1:bm1:\",\"cohortname\":\"M54AndUp\",\"enabled\":true,\"installdate\":5971,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.4c67e9ab7c30c48322e5f6fe5acbd64132c054ebb91bd510b414b1506167ffc9\"}]},\"ping\":{\"ping_freshness\":\"{81ec8067-30c8-459b-9549-92b1a581ef08}\",\"rd\":6066},\"updatecheck\":{},\"version\":"
		"\"9.47.0\"},{\"appid\":\"khaoiebndkojlmppeemjhbpbandiljpe\",\"brand\":\"GCEA\",\"cohort\":\"1:cux:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5971,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.05e2beeeef168c53566610c28f4301ec0a6211339fb14260fc08d6896f0341e7\"}]},\"ping\":{\"ping_freshness\":\"{1ede4f73-771e-49f8-814a-7179f6b750fe}\",\"rd\":6066},\"tag\":\"default\",\"updatecheck\":{},\"version\":\"61\"},{\"appid\":\"hfnkpimlhhgieaddgfemjhofmfblmnib\",\"brand\":\"GCEA\","
		"\"cohort\":\"1:jcl:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5971,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.f6ef3d9ef413c09e2612788995fee1e00c0700dadc0f7e5b0b53a047203a2b58\"}]},\"ping\":{\"ping_freshness\":\"{64af3d05-ef68-4b10-9053-573fa8907471}\",\"rd\":6066},\"updatecheck\":{},\"version\":\"8169\"},{\"appid\":\"laoigpblnllgcgjnjnllmfolckpjlhki\",\"brand\":\"GCEA\",\"cohort\":\"1:10zr:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5971,\"lang\":\""
		"en-US\",\"ping\":{\"ping_freshness\":\"{c3ffea16-deb6-4164-b58e-b6d1ba99b519}\",\"rd\":6066},\"updatecheck\":{},\"version\":\"1.0.7.1652906823\"},{\"accept_locale\":\"ENUS500000\",\"appid\":\"obedbbhbpmojnkanicioggnmelmoomoc\",\"brand\":\"GCEA\",\"cohort\":\"1:s6f:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5971,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.c6a2b5d414c3f81c83288c5b469da86843655012a11de08c3162af2d35272039\"}]},\"ping\":{\"ping_freshness\":\""
		"{621fcf89-e557-4e82-8eff-66bf0efd3192}\",\"rd\":6066},\"updatecheck\":{},\"version\":\"20230802.554445550.14\"},{\"appid\":\"ehgidpndbllacpjalkiimkbadgjfnnmc\",\"brand\":\"GCEA\",\"cohort\":\"1:ofl:\",\"cohortname\":\"stable64\",\"enabled\":true,\"installdate\":5971,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.a8a79d350c2a5e3bc36226633a8e0bed0dfab184e77f38fc8f0820ebacf8eafc\"}]},\"ping\":{\"ping_freshness\":\"{f82543d2-ca64-443f-8977-1acbfd321dec}\",\"rd\":6066},\"updatecheck\":{},\""
		"version\":\"2018.8.8.0\"},{\"appid\":\"llkgjffcdpffmhiakmfcdcblohccpfmo\",\"brand\":\"GCEA\",\"cohort\":\"1::\",\"enabled\":true,\"installdate\":5971,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.3e4f959036fef1cae2b1f426864a23f11caae1c96a2816523f2daf4213c3cc73\"}]},\"ping\":{\"ping_freshness\":\"{0e0e8d82-9ab6-47ff-b8ee-b3633a85129f}\",\"rd\":6066},\"updatecheck\":{},\"version\":\"1.0.0.14\"},{\"appid\":\"lmelglejhemejginpboagddgdfbepgmp\",\"brand\":\"GCEA\",\"cohort\":\"1:lwl:\",\""
		"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5971,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.637291d97df4f18b565debcf86891de8bc2ea0b137294c1069bff44864d74f7d\"}]},\"ping\":{\"ping_freshness\":\"{d4f4d73d-9b77-437c-a906-0455c5de85b8}\",\"rd\":6066},\"updatecheck\":{},\"version\":\"405\"},{\"appid\":\"kiabhabjdbkjdpjbpigfodbdjmbglcoo\",\"brand\":\"GCEA\",\"cohort\":\"1:v3l:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6065,\"lang\":\"en-US\",\"packages\":{\""
		"package\":[{\"fp\":\"1.8dbdf891d2522487b7bfb83486ea742486c57b13372bbbfacbbd7765b4145a11\"}]},\"ping\":{\"ping_freshness\":\"{5b11a186-10f4-4843-9276-5d9c574afaa1}\",\"rd\":6066},\"updatecheck\":{},\"version\":\"2023.8.8.3\"},{\"appid\":\"giekcmmlnklenlaomppkphknjmnnpneh\",\"brand\":\"GCEA\",\"cohort\":\"1:j5l:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5971,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.fd515ec0dc30d25a09641b8b83729234bc50f4511e35ce17d24fd996252eaace\"}]"
		"},\"ping\":{\"ping_freshness\":\"{0b063782-02d4-4fa6-8965-e9b0d2ff37e6}\",\"rd\":6066},\"updatecheck\":{},\"version\":\"7\"},{\"appid\":\"jflookgnkcckhobaglndicnbbgbonegd\",\"brand\":\"GCEA\",\"cohort\":\"1:s7x:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5971,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.202f4c3b173713c18031e8f1e7f271b999a59d8a8d14651225a287ca91c2751e\"}]},\"ping\":{\"ping_freshness\":\"{f4aa7d71-3ad9-4787-8e66-f46df04ea911}\",\"rd\":6066},\""
		"updatecheck\":{},\"version\":\"2987\"},{\"appid\":\"efniojlnjndmcbiieegkicadnoecjjef\",\"brand\":\"GCEA\",\"cohort\":\"1:18ql:\",\"cohortname\":\"Auto Stage3\",\"enabled\":true,\"installdate\":5971,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.7c9864699c68bff25256b15d79fea947f95707615610e34e5cb50f8bb0e7844d\"}]},\"ping\":{\"ping_freshness\":\"{37539d17-a171-4484-8281-3e29bcc3b19a}\",\"rd\":6066},\"updatecheck\":{},\"version\":\"670\"},{\"appid\":\"ojhpjlocmbogdgmfpkhlaaeamibhnphh\",\""
		"brand\":\"GCEA\",\"cohort\":\"1:w0x:\",\"cohortname\":\"All users\",\"enabled\":true,\"installdate\":5971,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.545666a4efd056351597bb386aea1368105ededc976ed5650d8682daab9f37ff\"}]},\"ping\":{\"ping_freshness\":\"{54fc8414-1510-4a7c-bfc6-a440d0f7f13a}\",\"rd\":6066},\"updatecheck\":{},\"version\":\"3\"},{\"appid\":\"jamhcnnkihinmdlkakkaopbjbbcngflc\",\"brand\":\"GCEA\",\"cohort\":\"1:wvr/1wdr/1wdx:\",\"cohortname\":\"Control\",\"enabled\":true,\""
		"installdate\":5971,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.1cf51b2226cb49c5fedd71899a6f36bca71017c67394be34708e76283c77ec1c\"}]},\"ping\":{\"ping_freshness\":\"{8d2938f1-e6f3-4ea3-8eab-7351e0aa27ea}\",\"rd\":6066},\"updatecheck\":{},\"version\":\"117.0.5938.0\"},{\"appid\":\"ggkkehgbnfjpeggfpleeakpidbkibbmn\",\"brand\":\"GCEA\",\"cohort\":\"1:ut9/1a0f:\",\"cohortname\":\"108-and-above-all-users\",\"enabled\":true,\"installdate\":5971,\"lang\":\"en-US\",\"packages\":{\"package\":["
		"{\"fp\":\"1.ed2f4d0fa9d2f99837719f80e3990498314290c6a294a72296ddcada784dd278\"}]},\"ping\":{\"ping_freshness\":\"{278a669c-b5cd-4d48-9012-d4f57ad0434f}\",\"rd\":6066},\"updatecheck\":{},\"version\":\"2022.12.16.779\"},{\"appid\":\"eeigpngbgcognadeebkilcpcaedhellh\",\"brand\":\"GCEA\",\"cohort\":\"1:w59:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5971,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.c64c9c1008f3ba5f6e18b3ca524bc98dcd8acfae0a2720a8f1f3ef0f8d643d05\"}]},\""
		"ping\":{\"ping_freshness\":\"{1bb597a8-55a4-4fa3-be98-25978dbe0091}\",\"rd\":6066},\"updatecheck\":{},\"version\":\"2020.11.2.164946\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":false,\"hw\":{\"avx\":true,\"physmemory\":16,\"sse\":true,\"sse2\":true,\"sse3\":true,\"sse41\":true,\"sse42\":true,\"ssse3\":true},\"ismachine\":true,\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.17763.1935\"},\"prodversion\":\"115.0.5790.171\",\"protocol\":\""
		"3.1\",\"requestid\":\"{4e550111-6ed3-47d0-b8b1-19346841e1a7}\",\"sessionid\":\"{1651e02d-4f0e-4a63-9b0c-25c9901d5fb9}\",\"updater\":{\"autoupdatecheckenabled\":true,\"ismachine\":true,\"lastchecked\":0,\"laststarted\":0,\"name\":\"Omaha\",\"updatepolicy\":-1,\"version\":\"1.3.36.292\"},\"updaterversion\":\"115.0.5790.171\"}}", 
		LAST);

	lr_think_time(8);

	web_submit_data("reservations.pl", 
		"Action=http://127.0.0.1:1080/cgi-bin/reservations.pl", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=http://127.0.0.1:1080/cgi-bin/reservations.pl?page=welcome", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=advanceDiscount", "Value=0", ENDITEM, 
		"Name=depart", "Value=San Francisco", ENDITEM, 
		"Name=departDate", "Value=08/14/2023", ENDITEM, 
		"Name=arrive", "Value=Paris", ENDITEM, 
		"Name=returnDate", "Value=08/15/2023", ENDITEM, 
		"Name=numPassengers", "Value=1", ENDITEM, 
		"Name=roundtrip", "Value=on", ENDITEM, 
		"Name=seatPref", "Value=None", ENDITEM, 
		"Name=seatType", "Value=Coach", ENDITEM, 
		"Name=findFlights.x", "Value=46", ENDITEM, 
		"Name=findFlights.y", "Value=7", ENDITEM, 
		"Name=.cgifields", "Value=roundtrip", ENDITEM, 
		"Name=.cgifields", "Value=seatType", ENDITEM, 
		"Name=.cgifields", "Value=seatPref", ENDITEM, 
		LAST);

	lr_think_time(4);

	web_submit_form("reservations.pl_2", 
		"Snapshot=t7.inf", 
		ITEMDATA, 
		"Name=outboundFlight", "Value=640;622;08/14/2023", ENDITEM, 
		"Name=returnFlight", "Value=460;622;08/15/2023", ENDITEM, 
		"Name=reserveFlights.x", "Value=43", ENDITEM, 
		"Name=reserveFlights.y", "Value=8", ENDITEM, 
		EXTRARES, 
		"Url=https://safebrowsing.googleapis.com/v4/threatListUpdates:fetch?$req="
		"Ch4KDGdvb2dsZWNocm9tZRIOMTE1LjAuNTc5MC4xNzEaKQgFEAEaGwoNCAUQBhgBIgMwMDEwARCPjxIaAhgHO0fLyiIEIAEgAigBGikIARABGhsKDQgBEAYYASIDMDAxMAEQ5-YMGgIYB39BFc8iBCABIAIoARopCAMQARobCg0IAxAGGAEiAzAwMTABEKTdDBoCGAcek-sIIgQgASACKAEaKQgOEAEaGwoNCA4QBhgBIgMwMDEwARC9jwcaAhgHDGUdLSIEIAEgAigBGigIARAIGhoKDQgBEAgYASIDMDAxMAQQ0DQaAhgHJgvyayIEIAEgAigEGikIDxABGhsKDQgPEAYYASIDMDAxMAEQ0KkBGgIYB0_fDc8iBCABIAIoARonCAoQCBoZCg0IChAIGAEiAzAwMTABEAcaAhgHRPylUyIEIAEgAigBGicICRABGhkKDQgJEAYYASIDMDAxMAEQIRoCGAcm7GMZIgQgASACKAEaKAgIEA"
		"EaGgoNCAgQBhgBIgMwMDEwARDcExoCGAemsuEDIgQgASACKAEaKQgNEAEaGwoNCA0QBhgBIgMwMDEwARDA9AEaAhgHa2ea3CIEIAEgAigBGikIBxABGhsKDQgHEAYYASIDMDAxMAEQ56wNGgIYB9diSQ4iBCABIAIoARooCBAQARoaCg0IEBAGGAEiAzAwMTABEO8bGgIYB91MwPAiBCABIAIoASICCAE=&$ct=application/x-protobuf&key=AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw", "Referer=", ENDITEM, 
		LAST);

	web_submit_form("reservations.pl_3", 
		"Snapshot=t8.inf", 
		ITEMDATA, 
		"Name=firstName", "Value=Jojo", ENDITEM, 
		"Name=lastName", "Value=Bean", ENDITEM, 
		"Name=address1", "Value=", ENDITEM, 
		"Name=address2", "Value=", ENDITEM, 
		"Name=pass1", "Value=Jojo Bean", ENDITEM, 
		"Name=creditCard", "Value=1234567890", ENDITEM, 
		"Name=expDate", "Value=12/23", ENDITEM, 
		"Name=saveCC", "Value=<OFF>", ENDITEM, 
		LAST);

	web_url("welcome.pl", 
		"URL=http://127.0.0.1:1080/cgi-bin/welcome.pl?signOff=1", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://127.0.0.1:1080/cgi-bin/nav.pl?page=menu&in=flights", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);

	return 0;
}