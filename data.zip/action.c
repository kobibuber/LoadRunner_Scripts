Action()
{

	web_url("Index.htm", 
		"URL=http://127.0.0.1:1080/WebTours/Index.htm", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://clientservices.googleapis.com/chrome-variations/seed?osname=win&channel=stable&milestone=116", "Referer=", ENDITEM, 
		"Url=https://content-autofill.googleapis.com/v1/pages/ChVDaHJvbWUvMTE2LjAuNTg0NS4xMTESFwk32UHgj34xiRIFDeeNQA4SBQ3OQUx6?alt=proto", "Referer=", ENDITEM, 
		LAST);

	web_set_sockets_option("SSL_VERSION", "AUTO");

	lr_think_time(52);

	web_custom_request("json", 
		"URL=https://update.googleapis.com/service/update2/json?cup2key=13:a3nAevVehX1JT2Mw8XWeb8FZm0Z5mIl80N-2BRYbjmY&cup2hreq=ed751ad21a6d70eab93596c596e123771818030243797c3d700b06bc49da3557", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx3,puff\",\"app\":[{\"appid\":\"gcmjkmgdlgnkkcocmoeiminaijmmjnii\",\"brand\":\"GCEA\",\"cohort\":\"1:bm1:\",\"cohortname\":\"M54AndUp\",\"enabled\":true,\"installdate\":5971,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.4c67e9ab7c30c48322e5f6fe5acbd64132c054ebb91bd510b414b1506167ffc9\"}]},\"ping\":{\"ping_freshness\":\"{6a9f328a-c915-4d4c-92be-101d6b5c6d3e}\",\"rd\":6077},\"updatecheck\":{},\"version\":\""
		"9.47.0\"},{\"accept_locale\":\"ENUS500000\",\"appid\":\"obedbbhbpmojnkanicioggnmelmoomoc\",\"brand\":\"GCEA\",\"cohort\":\"1:s6f:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5971,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.c6a2b5d414c3f81c83288c5b469da86843655012a11de08c3162af2d35272039\"}]},\"ping\":{\"ping_freshness\":\"{7a41f14d-7681-4084-8e96-0a682ed176b3}\",\"rd\":6077},\"updatecheck\":{},\"version\":\"20230802.554445550.14\"},{\"appid\":\""
		"lmelglejhemejginpboagddgdfbepgmp\",\"brand\":\"GCEA\",\"cohort\":\"1:lwl:1x43@0.025\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5971,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.10e773e5fb568810c033464e3e821898761e94b7e0ffadcf01dea71e27642e43\"}]},\"ping\":{\"ping_freshness\":\"{7badc35f-d3a1-4ec2-b781-0977f5955b4a}\",\"rd\":6077},\"updatecheck\":{},\"version\":\"408\"},{\"appid\":\"kiabhabjdbkjdpjbpigfodbdjmbglcoo\",\"brand\":\"GCEA\",\"cohort\":\"1:v3l:\",\""
		"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6065,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.8dbdf891d2522487b7bfb83486ea742486c57b13372bbbfacbbd7765b4145a11\"}]},\"ping\":{\"ping_freshness\":\"{93628e8d-400c-4fd4-a2e1-37458e857a66}\",\"rd\":6077},\"updatecheck\":{},\"version\":\"2023.8.8.3\"},{\"appid\":\"giekcmmlnklenlaomppkphknjmnnpneh\",\"brand\":\"GCEA\",\"cohort\":\"1:j5l:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5971,\"lang\":\"en-US\",\"packages\""
		":{\"package\":[{\"fp\":\"1.fd515ec0dc30d25a09641b8b83729234bc50f4511e35ce17d24fd996252eaace\"}]},\"ping\":{\"ping_freshness\":\"{714ed6b7-447d-48b6-a5d6-e3ef905db755}\",\"rd\":6077},\"updatecheck\":{},\"version\":\"7\"},{\"appid\":\"khaoiebndkojlmppeemjhbpbandiljpe\",\"brand\":\"GCEA\",\"cohort\":\"1:cux:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5971,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.05e2beeeef168c53566610c28f4301ec0a6211339fb14260fc08d6896f0341e7\"}]},\""
		"ping\":{\"ping_freshness\":\"{d8f1887c-1ed8-4a29-903d-22db17feec63}\",\"rd\":6077},\"tag\":\"default\",\"updatecheck\":{},\"version\":\"61\"},{\"appid\":\"ihnlcenocehgdaegdmhbidjhnhdchfmm\",\"brand\":\"GCEA\",\"cohort\":\"1::\",\"enabled\":true,\"installdate\":5971,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{f86ba3e4-5f06-4b09-86d2-f144c907087e}\",\"rd\":6077},\"updatecheck\":{},\"version\":\"0.0.0.0\"},{\"appid\":\"llkgjffcdpffmhiakmfcdcblohccpfmo\",\"brand\":\"GCEA\",\"cohort\":\"1::\",\""
		"enabled\":true,\"installdate\":5971,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.3e4f959036fef1cae2b1f426864a23f11caae1c96a2816523f2daf4213c3cc73\"}]},\"ping\":{\"ping_freshness\":\"{d2537404-94a0-434d-ba76-3f3b0ad92244}\",\"rd\":6077},\"updatecheck\":{},\"version\":\"1.0.0.14\"},{\"appid\":\"laoigpblnllgcgjnjnllmfolckpjlhki\",\"brand\":\"GCEA\",\"cohort\":\"1:10zr:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5971,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\""
		"{73216d6e-8042-4569-b663-a8e4f9c58ec2}\",\"rd\":6077},\"updatecheck\":{},\"version\":\"1.0.7.1652906823\"},{\"appid\":\"ehgidpndbllacpjalkiimkbadgjfnnmc\",\"brand\":\"GCEA\",\"cohort\":\"1:ofl:\",\"cohortname\":\"stable64\",\"enabled\":true,\"installdate\":5971,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.a8a79d350c2a5e3bc36226633a8e0bed0dfab184e77f38fc8f0820ebacf8eafc\"}]},\"ping\":{\"ping_freshness\":\"{a53cd08f-967a-4130-ba4a-6bb2ec728957}\",\"rd\":6077},\"updatecheck\":{},\""
		"version\":\"2018.8.8.0\"},{\"_internal_experimental_sets\":\"false\",\"appid\":\"gonpemdgkjcecdgbnaabipppbmgfggbe\",\"brand\":\"GCEA\",\"cohort\":\"1:z1x:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5971,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.5a506939f22e0e53bd8b919b551401480815141ab3143004ac047b045713615b\"}]},\"ping\":{\"ping_freshness\":\"{03cced37-ab2d-4075-832e-4249802b4c2e}\",\"rd\":6077},\"updatecheck\":{},\"version\":\"2023.8.9.0\"},{\"appid\":\""
		"jflookgnkcckhobaglndicnbbgbonegd\",\"brand\":\"GCEA\",\"cohort\":\"1:s7x:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5971,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.c00391e6ee5379830c85cbd3e8453aa90a5282a72b86b4673430a6a94e0781c1\"}]},\"ping\":{\"ping_freshness\":\"{3e02c3d3-1657-4925-b89a-39b577c66917}\",\"rd\":6077},\"updatecheck\":{},\"version\":\"2988\"},{\"appid\":\"ggkkehgbnfjpeggfpleeakpidbkibbmn\",\"brand\":\"GCEA\",\"cohort\":\"1:ut9/1a0f:\",\"cohortname\":"
		"\"108-and-above-all-users\",\"enabled\":true,\"installdate\":5971,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.ed2f4d0fa9d2f99837719f80e3990498314290c6a294a72296ddcada784dd278\"}]},\"ping\":{\"ping_freshness\":\"{47fea926-0368-40ab-baeb-52d6d26230bf}\",\"rd\":6077},\"updatecheck\":{},\"version\":\"2022.12.16.779\"},{\"appid\":\"jamhcnnkihinmdlkakkaopbjbbcngflc\",\"brand\":\"GCEA\",\"cohort\":\"1:wvr:1x1x@0.1\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5971,\"lang\":\""
		"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.44d98784c2b39c8074ea908fd42ef654459ad350553b44b124ffb42ab2b897f7\"}]},\"ping\":{\"ping_freshness\":\"{733aacc3-7985-4f38-8bec-1f85b13a8550}\",\"rd\":6077},\"updatecheck\":{},\"version\":\"118.0.5957.0\"},{\"appid\":\"efniojlnjndmcbiieegkicadnoecjjef\",\"brand\":\"GCEA\",\"cohort\":\"1:18ql:\",\"cohortname\":\"Auto Stage3\",\"enabled\":true,\"installdate\":5971,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\""
		"1.64f0db2cba2da454b87dc6447f861f5eb5fd587b614cbc2baf00a4668ca0e439\"}]},\"ping\":{\"ping_freshness\":\"{e38ae173-78af-4eef-b742-280bcd4a0b48}\",\"rd\":6077},\"updatecheck\":{},\"version\":\"685\"},{\"appid\":\"ojhpjlocmbogdgmfpkhlaaeamibhnphh\",\"brand\":\"GCEA\",\"cohort\":\"1:w0x:\",\"cohortname\":\"All users\",\"enabled\":true,\"installdate\":5971,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.545666a4efd056351597bb386aea1368105ededc976ed5650d8682daab9f37ff\"}]},\"ping\":{\""
		"ping_freshness\":\"{38662c89-fb7c-4f7f-8292-0439287fe0c8}\",\"rd\":6077},\"updatecheck\":{},\"version\":\"3\"},{\"appid\":\"hnimpnehoodheedghdeeijklkeaacbdc\",\"brand\":\"GCEA\",\"cohort\":\"1::\",\"enabled\":true,\"installdate\":5971,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.6f6bc93dcd62dc251850d2ff458fda96083ceb7fbe8eeb11248b8485ef2aea23\"}]},\"ping\":{\"ping_freshness\":\"{a996a1f6-16a1-4e11-b2ad-ba81551bc52d}\",\"rd\":6077},\"updatecheck\":{},\"version\":\"0.57.44.2492\"},{\""
		"appid\":\"oimompecagnajdejgnnjijobebaeigek\",\"brand\":\"GCEA\",\"cohort\":\"1:1unx/1wwf:1wwl@0.5\",\"cohortname\":\"Rollout\",\"enabled\":true,\"installdate\":5971,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{da61c545-28fa-439e-9746-2e96ca3c7d6f}\",\"rd\":6077},\"updatecheck\":{},\"version\":\"4.10.2662.3\"},{\"appid\":\"hfnkpimlhhgieaddgfemjhofmfblmnib\",\"brand\":\"GCEA\",\"cohort\":\"1:jcl:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5971,\"lang\":\"en-US\",\"packages\":{"
		"\"package\":[{\"fp\":\"1.14fc4dff8cc8dc7956c033ed07162385172ec85caaa94554e274e45e63374e15\"}]},\"ping\":{\"ping_freshness\":\"{4b33c65e-b1e5-44b4-8807-38aaabb459d3}\",\"rd\":6077},\"updatecheck\":{},\"version\":\"8194\"},{\"appid\":\"eeigpngbgcognadeebkilcpcaedhellh\",\"brand\":\"GCEA\",\"cohort\":\"1:w59:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5971,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.c64c9c1008f3ba5f6e18b3ca524bc98dcd8acfae0a2720a8f1f3ef0f8d643d05\"}]},\""
		"ping\":{\"ping_freshness\":\"{9a105b5a-10a0-4e1e-8511-479446055d84}\",\"rd\":6077},\"updatecheck\":{},\"version\":\"2020.11.2.164946\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":false,\"hw\":{\"avx\":true,\"physmemory\":16,\"sse\":true,\"sse2\":true,\"sse3\":true,\"sse41\":true,\"sse42\":true,\"ssse3\":true},\"ismachine\":true,\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.17763.1935\"},\"prodversion\":\"116.0.5845.111\",\"protocol\":\""
		"3.1\",\"requestid\":\"{e30afb7d-7880-4cc8-8283-38fe132982d2}\",\"sessionid\":\"{1dfa5efa-f975-4b7b-be6f-1570ac3509b1}\",\"updater\":{\"autoupdatecheckenabled\":true,\"ismachine\":true,\"lastchecked\":0,\"laststarted\":0,\"name\":\"Omaha\",\"updatepolicy\":-1,\"version\":\"1.3.36.292\"},\"updaterversion\":\"116.0.5845.111\"}}", 
		LAST);

	lr_think_time(4);

	web_custom_request("json_2", 
		"URL=https://update.googleapis.com/service/update2/json", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx3,puff\",\"app\":[{\"appid\":\"lmelglejhemejginpboagddgdfbepgmp\",\"brand\":\"GCEA\",\"cohort\":\"1:lwl:\",\"cohortname\":\"Auto\",\"enabled\":true,\"event\":[{\"download_time_ms\":4346,\"downloaded\":2136,\"downloader\":\"bits\",\"eventresult\":1,\"eventtype\":14,\"nextversion\":\"409\",\"previousversion\":\"408\",\"total\":2136,\"url\":\"http://edgedl.me.gvt1.com/edgedl/diffgen-puffin/"
		"lmelglejhemejginpboagddgdfbepgmp/1.dece35abb54406499e329dbfd928038b0c154d3111dc5ca2681799d528db5abc/1.10e773e5fb568810c033464e3e821898761e94b7e0ffadcf01dea71e27642e43/3304a567e6c7bb4082089ef5dffacbccf7a71c9275f339efac093d9680937a9e.puff\"},{\"diffresult\":1,\"eventresult\":1,\"eventtype\":3,\"nextfp\":\"1.dece35abb54406499e329dbfd928038b0c154d3111dc5ca2681799d528db5abc\",\"nextversion\":\"409\",\"previousfp\":\"1.10e773e5fb568810c033464e3e821898761e94b7e0ffadcf01dea71e27642e43\",\"previousversion"
		"\":\"408\"}],\"installdate\":5971,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.dece35abb54406499e329dbfd928038b0c154d3111dc5ca2681799d528db5abc\"}]},\"version\":\"409\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":false,\"hw\":{\"avx\":true,\"physmemory\":16,\"sse\":true,\"sse2\":true,\"sse3\":true,\"sse41\":true,\"sse42\":true,\"ssse3\":true},\"ismachine\":true,\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.17763.1935\"},\""
		"prodversion\":\"116.0.5845.111\",\"protocol\":\"3.1\",\"requestid\":\"{c44e3fe8-9880-4a83-bc33-0125227f8d98}\",\"sessionid\":\"{1dfa5efa-f975-4b7b-be6f-1570ac3509b1}\",\"updaterversion\":\"116.0.5845.111\"}}", 
		LAST);

	lr_think_time(163);

	web_submit_data("login.pl", 
		"Action=http://127.0.0.1:1080/cgi-bin/login.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://127.0.0.1:1080/cgi-bin/nav.pl?in=home", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=userSession", "Value=137158.983718104HAffVVfpccftcDDApzQVDf", ENDITEM, 
		"Name=username", "Value=jojo", ENDITEM, 
		"Name=password", "Value=nean", ENDITEM, 
		"Name=login.x", "Value=60", ENDITEM, 
		"Name=login.y", "Value=15", ENDITEM, 
		"Name=JSFormSubmit", "Value=off", ENDITEM, 
		LAST);

	return 0;
}